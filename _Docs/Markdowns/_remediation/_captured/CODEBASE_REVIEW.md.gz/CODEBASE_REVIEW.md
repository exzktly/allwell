# All-Well codebase review — findings report

Scope: the whole repository **except** the Analyze pane and the analysis pipeline
(`process_microscopy.py`, `pipeline/`, `analyze_*.py`). `util/` is included because it
is shared Qt-free ground; where a `util/` defect surfaces in the Analyze form that is
noted, because the defect itself lives in the reviewed code.

Ten independent reviewers covered: `well_viewer/domain/`, `well_viewer/core/` +
`runtime_app`, `well_viewer/data/` + `persistence/`, the plotting features, the
`image_browser` stack, `home/` + `saved_plots/`, `export`/`qc`/`smfish`/`spatial`/
`multivariate`, `widgets/` + `theme.py`, `datasets/`, and `util/` + the shell.
The reviewers returned 178 findings; consolidated here into 177 entries (overlapping
duplicates merged, and a few rows cover more than one site). Nothing in the
repository was modified.

## Severity key

| Rating | Meaning |
|---|---|
| **Critical** | Produces or destroys data that is wrong and looks right — a scientific result the user would publish, or a user's saved work silently lost. |
| **High** | A wrong number, a wrong image, or a feature that cannot work at all; visible to a user who is looking, but not announced. |
| **Medium** | Wrong in a reachable but narrower case, or a degraded result the artifact does not mark as degraded. |
| **Low** | Latent (no live caller today), cosmetic, or a documentation/contract mismatch. |

## Totals

| Theme | Critical | High | Medium | Low | Total |
|---|---:|---:|---:|---:|---:|
| 1. Silent degradation — zero vs. never-computed | 0 | 4 | 16 | 4 | 24 |
| 2. Statistics and error bars | 0 | 6 | 5 | 4 | 15 |
| 3. Fold change and normalization | 0 | 4 | 3 | 3 | 10 |
| 4. Image and frame identity | 1 | 3 | 5 | 5 | 14 |
| 5. Destructive dataset operations | 1 | 3 | 6 | 3 | 13 |
| 6. Persistence and cross-dataset state leakage | 0 | 3 | 9 | 2 | 14 |
| 7. Export does not match the screen | 2 | 3 | 6 | 3 | 14 |
| 8. Controls that cannot work | 0 | 3 | 6 | 3 | 12 |
| 9. Threading and lifecycle | 0 | 2 | 7 | 1 | 10 |
| 10. Half-swept predicates and duplicated logic | 2 | 3 | 10 | 3 | 18 |
| 11. Rendering, theming and widget state | 0 | 0 | 6 | 9 | 15 |
| 12. Docs, contracts and guard gaps | 0 | 1 | 2 | 15 | 18 |
| **Total** | **6** | **35** | **81** | **55** | **177** |

---

## Theme 1 — Silent degradation: "computed as zero" vs. "never computed"

The repo's own design rule is that degraded output must never be indistinguishable
from good output. This is the largest cluster of violations, and the one that most
directly puts a wrong number in a figure.

| Location | Problem | Severity |
|---|---|---|
| `well_viewer/features/smfish/worker.py:179,305,346` | A well whose spot-counting pass raises is logged and then dropped from `counts`; `counts.get(k, 0)` writes a full column of `0` into that well's CSV and `done_cb` still reports "Apply to All complete". A per-file "0 matched rows" warning exists in the log, but the artifact itself is a plausible column of zeros. | High |
| `well_viewer/features/image_browser/image_table/image_compose.py:244` | `_export_binary_mask` catches every exception into `above_by_nid = {}` and renders an all-black silhouette — identical to "no cells above threshold". Same all-black result when the well's CSV rows do not cover the displayed `(fov, tp)`. The assignment body evades `test_no_silent_except.py`. | Medium |
| `well_viewer/features/heatmap/controller.py:294` | `METRIC_COUNT` returns `0.0` (not NaN) when nothing matches, so a well that failed to compute colours as a genuine zero-count well. | Medium |
| `well_viewer/features/barplot/controller.py:233`, `renderer.py:1223` | The Events bar is gated on `n_above > 0`, so a measured zero renders as "never computed" — the same conflation in the other direction. | Medium |
| `well_viewer/domain/stats_compute.py:210` | `_reduce_reps` returns spread `0.0` for n=1 where `_aggregate_arrays` returns NaN and its own docstring promises "never 0.0". A one-well replicate set exports `err_SD = 0.000000`. | Medium |
| `well_viewer/domain/stats_compute.py:372,449` | A NaN events-mean is coerced to `0.0` while the mean and fraction in the same tuple stay NaN — one tuple, two conventions, so Mean and Fraction draw nothing and Events draws a bar at exactly 0. | Medium |
| `well_viewer/domain/spatial_compute.py:585` | `radial_profile` gives a one-cell bin `sem = 0.0` while empty bins correctly get NaN. The misleading case is the one drawn as data. | Medium |
| `well_viewer/domain/spatial_compute.py:136` | `ripley_l` with n<2 returns an all-zero curve **and** a zero-width CSR envelope: a one-cell frame renders as perfect CSR with zero uncertainty. | Low–Medium |
| `well_viewer/features/spatial/renderer.py:464` | An empty partition is substituted with `np.array([0.0])` and drawn as a violin. | Medium |
| `well_viewer/features/multivariate/renderer.py:199` | SPLOM silently truncates to 6 features with no footnote on the figure. | Medium |
| `well_viewer/data/data_loading.py:561,782` | A CSV without `area_px` returns empty from both aggregation entry points **with no log line**; every plot draws nothing and nothing says why. | Medium |
| `well_viewer/data/zip_members.py:215` | A mid-scan exception returns partially filled dicts indistinguishable from a complete scan, under a "Result: N fluor…" line that reads as an inventory. | Medium |
| `well_viewer/data/crop_tool.py:186` | A crop clamping to an empty rectangle returns the full array while the status still reads `Crop: 300×300 px`. | Low |
| `well_viewer/features/batch_export/bar_panel.py:552` | An empty item set writes a fully labelled blank figure, no CSV, and returns success. | High |
| `well_viewer/features/batch_export/base_panel.py:1831` | The line batch skips the CSV when there are no rows but still saves the figure and reports success. | High |
| `well_viewer/features/batch_export/scatter_panel.py:489,717,754` | One empty `(group, tp)` returns an error string that discards the entire batch's staging. | Medium |
| `datasets/job_queue/controller.py:303` | A queued job that never ran is marked **succeeded**, carrying the message and `dataset_root` of an unrelated manual run. | High |
| `datasets/subset/apply.py:242` | The "did anything land?" check is skipped exactly when the filtered archive came out empty — "nothing to compare against" conflated with "nothing landed". | Medium |
| `datasets/merge_plates/apply.py:133,154` | `copy_container_members`' `dropped` set (real data loss) is bound to `_dropped` and thrown away; Concatenate makes the same event a hard failure. | Medium |
| `datasets/concatenate/concatenate_compute.py:267` | Dataset 2's `sample_definitions` / `notes` / `ratios` are dropped with no log line, even though `wells_ds2_only` is normally non-empty. | Low–Medium |
| `util/disk_space.py:57` | `os.walk` never raises, so the outer handler is dead code and an unreadable subtree silently counts 0 bytes. | Low |
| `util/zip_write.py:185` | `folder_removed=True` is returned even when the removal actually failed. | Low |
| `well_viewer/data/cache_projectors.py:79` | A verdict that raises during re-projection leaves the previous `QC_Pass`/`Crop_Pass` values attached: plots filter by the old parameters while the UI shows the new ones. | Low |
| `well_viewer/features/smfish/tab_view.py:759` | An unparseable threshold silently becomes `0.0` and is applied plate-wide. | Medium |

## Theme 2 — Statistics and error bars

| Location | Problem | Severity |
|---|---|---|
| `well_viewer/features/lineplot/controller.py:325`, `well_viewer/features/barplot/collect.py:841`, `well_viewer/features/batch_export/_line_series_runner.py:180` | `compute_rep_stats` returns a 4-tuple whose fourth element is the fraction spread. `barplot/collect.py:429` binds it as `g_err_f`; these three siblings discard it (`, _ =`) and then hard-set `gfe = 0.0`. The Line tab's Fraction panel and the batch bar path lose their error band entirely while the Bar tab keeps it. | High |
| `well_viewer/features/lineplot/controller.py:454` | `LinePoint.n_above_spread` is populated at `:335` and then ignored at the draw site, which passes a literal `0.0`. The Line tab's Events panel never shows a replicate error bar the Bar tab does show. | High |
| `well_viewer/domain/stats_compute.py:181` | The FOV branch of `group_replicate_stats` never consults `fov_integrity.check_fov_labels`, the verdict that exists because "six fields pooled under one label turn the mean events per field into the total — six times too large". An untrustworthy well reads "undefined" as a solo bar and 6× as a set member, in one figure. | High |
| `well_viewer/features/scatter/controller.py:128` + `gating.py:505` | The gate percentage is denominated by the already gate-filtered cloud, so "Apply gates" makes every label read `100.0%`. | High |
| `well_viewer/features/export/sidebar_view.py:476` | `_sync_err_from_app` never writes `bar_err_kind`, so `ci95` survives a SEM/SD flip: bars draw 1.96 × SD under a label reading "SD". | High |
| `well_viewer/domain/stats_compute.py:319,353,398,437` | The stats-cache keys fold in `active_val_col` — a bare `ratio:<name>` string — but never `ratio_index`, and `channel_state_controller.set_ratio_metrics:831` never calls `invalidate_stats_cache` (twelve other mutation sites do). Editing a ratio in place leaves every rep-set entry valid by key and wrong by value. | Medium–High |
| `well_viewer/features/heatmap/controller.py:270` | The replicate-set average is a pool-of-cells mean, not the mean-of-per-well-means Bar, Line and Stats use. Possibly deliberate; undocumented either way. | Medium |
| `well_viewer/features/home/cell_gating/gating_compute.py:426` | The optimizer's fraction-on population (QC + Crop only) is not the plots' denominator, so its reported fractions and its argmax do not match the bar plot. | Medium |
| `well_viewer/features/barplot/collect.py:519` vs `:679` | `has_frac` couples to `has_mean` only in the grouped branch: a set with zero above-threshold cells shows a placeholder pooled and an honest 0 unpooled. | Medium |
| `well_viewer/features/barplot/renderer.py:1223` | The per-cell Events panel ignores `bar_err_settings`, so "None" and "95 % CI" apply to grouped mode only. | Medium |
| `well_viewer/features/barplot/renderer.py:526` | `x_by_key` collapses duplicate keys in multi-timepoint mode, so significance brackets are drawn over the last timepoint's bars rather than the tested one. | Medium |
| `well_viewer/features/qc/tab_view.py:171` | `_num(...) or None` drops a deliberately typed `0` bound. | Low |
| `well_viewer/domain/fold_change.py:92,148` | `isinstance(x, (int, float))` rejects `numpy.float32`, giving a NaN mean and a lost error bar. Latent (no live float32 producer found) but the exact class CLAUDE.md §7.5 #8 records in this module. | Low |
| `well_viewer/features/export/service.py:148` | The line CSV writes a literal `nan` spread where the bar CSV writes `""`. | Low |
| `well_viewer/domain/ratio_models.py:24` | Docstring says epsilon is *added*; the resolver *clamps* (`np.maximum(den, epsilon)`) — different numbers near and below zero on background-subtracted channels. | Low |

## Theme 3 — Fold change and normalization

| Location | Problem | Severity |
|---|---|---|
| `well_viewer/domain/fold_change.py:296,713,785` | Every baseline search requires `v != 0`, so a fraction-on or event count of exactly 0 at t0 — the expected value of an induction experiment — is skipped and a **later timepoint** is silently substituted. Measured: the mean panel normalizes to t=0 while the fraction and events panels normalize to t=24, in one figure under one axis label. For *ratio* mode skipping a zero divisor is defensible; for *subtract* mode subtracting 0 is well-defined and the skip is simply wrong. | High |
| `well_viewer/features/lineplot/controller.py:741` | `ax_frac.set_ylim(-0.05, 1.05)` unconditionally, so under fold change the fraction panel clips every ratio above 1.05 out of view. Bar's `_set_frac_ylim` skips the clamp for exactly this reason. | High |
| `well_viewer/features/barplot/renderer.py:197,394` | The violin/beeswarm Fraction panel plots raw fractions but is given the fold-change title suffix. `draw_per_well_n_bars` guards against this; the fraction panel does not. | High |
| `well_viewer/core/load_controller.py:326` | `PlotState`'s fold-change block (`fc_vs_control_on`, `fc_control`, `fc_control_map`, `focus_timepoint`, `line_order_*`, `bar_group_mode`) is never reset on a dataset swap, and `view_state.load_from_data_dir` early-returns when the new plate has no saved block. Plate B comes up normalized against plate A's group — every bar NaN under a fold-change axis label. | High |
| `well_viewer/domain/fold_change.py:148` vs `:1882` | The line path folds an undefined (NaN) spread to `0.0`; the bar path preserves NaN. `scale_bar_value`'s own docstring states the rule `_scale_pt` breaks four hundred lines above it. | Medium |
| `well_viewer/features/batch_export/base_panel.py:224` | An inherited per-member control mode shows `—` in the Control combo while the export normalizes anyway. | Medium |
| `well_viewer/domain/fold_change.py:589` | The events replicate spread (index 9) is not normalized while its value (index 4) is. Invisible only because the Line draw site passes `0.0` for that panel. | Low |
| `well_viewer/domain/fold_change_pairing.py:516` | `tick_labels` de-duplicates by reference and `distinct_controls` by resolved wells, so a one-well control set plus that well's own token gives an axis title naming one control above tick rows naming two. | Low |
| `well_viewer/core/fold_change_pairing_view.py:226,356` | One row edit rebuilds the table twice, and `setCellWidget` destroys the combo whose slot is still on the stack — roughly 192 combos per edit on a 96-member plate. | Medium |
| `well_viewer/domain/fold_change_scopes.py:88` | A bare `except → frozenset()` with no log makes `redraw_scopes_or_defer` defer every scope: the fold-change controls silently stop working. | Low |

## Theme 4 — Image and frame identity

| Location | Problem | Severity |
|---|---|---|
| `well_viewer/data/image_identity.py:190,194` and `well_viewer/data/image_resolver.py:122` | Both classifiers call `Path(stripped).stem` on an **already-stripped field stem**, truncating any schema token that contains a dot. Reproduced: `classify_filename_role("A1_f1_1.5h_w2_labels.tif")` → `(MASK, 'A1_f1_1')`. A `1.5h` mask or tophat is keyed `tp="1"`, so it loses its own mask *and* collides with the genuine `1h`/`T01` key on a first-hit-wins lookup. | Critical |
| `well_viewer/data/image_discovery.py:596` | The loose-file fallback's `else:` files `smfish` images into the **mask** dict; `load_mask_array` then `rint`s spot intensities into an int32 label image. | High |
| `well_viewer/data/frame_load.py:266` | The ambiguity refusal covers an empty FOV but not an empty timepoint, which matches every key and returns `hits[0]` as a successful `"normalized"` resolution. | High |
| `well_viewer/features/image_browser/image_table/facet_view.py:187` | The wrap-cols banded layout derives its single column-header strip from row 0 only, so every band below the first is labelled with the *first* band's values (2 ch × 6 tp, wrap 3 → rows 2–3 show T4–T6 under a header reading T1–T3). Export replays the same plan. Documented as a known limitation at ARCHITECTURE line 2141; nothing in the UI says so. | High |
| `well_viewer/features/image_browser/image_table/facet_view.py:186` | Row labels read only column 0 and column labels only row 0, so a deliberately blank cell there deletes that band's axis label instead of falling back to a populated cell. | Medium |
| `well_viewer/data/image_resolver.py:135` | `normalize_numeric_token` uses `str(value or "")`, so numeric zero becomes `""` — dropping a `0` entry from `timepoint_options`/`fov_options` and turning an empty target into "match anything". `image_identity._raw_token` documents this exact defect as fixed, in the other copy. | Medium |
| `well_viewer/data/data_loading.py:911` + `image_discovery.py:559` | An unparseable well label yields `well_token=None`, which **disables** the per-well filter in the loose-file fallback, so every well's images are accepted into that one well. | Medium |
| `well_viewer/features/image_browser/image_table/controller.py:789` + `image_compose.py:1070` | An Overlay cell can never carry the `raw` uncorrected badge, so the status line counts uncorrected cells no badge ever identifies. | Medium |
| `well_viewer/core/image_view_state.py:31` | `lut_by_channel` / `tint_by_channel` are neither persisted nor cleared on swap: a bright plate's LUT renders the next plate black. | Medium |
| `well_viewer/features/image_browser/image_table/image_compose.py:1070` | A ratio cell's raw-fallback is recorded under the numerator/denominator channel, so it is never badged and is counted under a channel absent from the grid. | Low |
| `well_viewer/features/image_browser/image_table/image_compose.py:758` | `composite_column_rgb` calls `_row_display_opts(ctx, r)` with no channel, so it always loads the **raw** frame for a corrected channel. Dead today (re-export only). | Low |
| `well_viewer/features/image_browser/image_table/image_compose.py:374` | `_parse_lut`'s no-spec fallback applies column 0's channel LUT to the whole row. Reachable only with an empty `channel_opts`. | Low |
| `well_viewer/features/image_browser/image_table/controller.py:795` | Overlay cells install a hover readout keyed on the sentinel channel, so their pixel readout can never resolve and is always empty. | Low |
| `well_viewer/data/image_resolver.py:109` vs `image_identity.py:159` | Two filename classifiers; the one the scan path uses has no `_phase` entry, so a `Role.PHASE` output would be served as a raw fluor frame. Docs name `image_identity` the single source of truth. | Low |

## Theme 5 — Destructive dataset operations

| Location | Problem | Severity |
|---|---|---|
| `datasets/merge_plates/merge_plates_compute.py:130,292` | `merge_sample_definitions` reads only the **legacy v1** `rep_sets`/`groups`; today's on-disk shape is v2 `selections`. Its result *replaces* dataset 1's whole block. Reproduced: merging two plates with current-app Sample Definitions yields `{"well_labels": {...}, "rep_sets": [], "groups": []}` — every selection, replicate set, group, plot group, `current_id` and `notes` from **both** datasets gone, reported as a clean success. Concatenate preserves what Merge Plates deletes. | Critical |
| `datasets/ome_import/apply.py:53`, `worker.py:48` | No run-time destination check: `destination_problem` / `resume_state(...).mismatched` are consulted only by `view.py`. A queued OME job overwrites each `in/<WELL>.zip` while `out/` survives — measurements that no longer match their inputs, reported as success; and a `mismatched` marker is ignored, stitching one folder from two mappings. | High |
| `datasets/validate/apply.py:136` | `apply_repairs` rewrites the live `out/pipeline_info.json` with a truncating `write_text`, while its sibling `validate/record.py:152` writes the same file tmp + `Path.replace`. A crash mid-apply destroys `cell_gating`, `sample_definitions`, `ratios` and `notes` — the four blocks this module's docstring is a paragraph about preserving — with no backup. | High |
| `datasets/merge_plates/apply.py:83` | `_remap._rename` discards `rewrite_member_field`'s `was_rewritten` flag, so a member failing the structural gate keeps dataset 2's original well token inside the destination well's archive, silently. The CSV row is equally unrewritten, so the `dest_in_names` check still passes. | High |
| `datasets/import_loose/apply.py:179` | In-place mode zips and unlinks the TIFs of **every** well-named subfolder under the source, including pre-existing ones; the preview is non-recursive and loose-TIF-only. Bytes survive in the archives, so this is unannounced scope rather than loss — but preview ≠ apply on the pane's one destructive path. | Medium |
| `datasets/subset/subset_compute.py:215` vs `:182` | `row_matches` reads the `timepoint_hours` **column** and `member_matches` reads the **filename** token. A legacy CSV with a blank `timepoint_hours` loses every row while all images copy, and `_verify` names the wrong cause. | Medium |
| `datasets/_common/dataset_paths.py:187` | Two containers canonicalising to the same well (`A1.zip` + `A01.zip`) collapse by plain dict overwrite in glob order. The `out_csvs` sibling documents its identical overwrite and names the caller that must not trust it; the input side has no warning and every copy tool trusts it. | Medium |
| `datasets/_common/containers.py:318` | The tier-1 whole-file path writes with `shutil.copy2` straight onto `dest`, outside the `atomic_zip` guarantee the module docstring states without exception. An interrupted wells-only Subset leaves a truncated `in/<WELL>.zip`. | Low |
| `util/zip_write.py:250` | `atomic_zip`'s verification is name-only. With 200 bytes flipped in the deflate stream the archive still publishes; `testzip()` reports `Bad CRC-32`. The invariant verified is "the index is complete", not the docstring's "readable". | Medium |
| `util/zip_write.py:154` | `replace_folder_with_archive`'s `resolve()` identity conflates symlink and hardlink aliases in both directions: an archived symlink is reported as `kept`, and a second name for an archived file is destroyed by the folder removal though the archive holds no member under that name. | Low |
| `WellPlateZipper.py:180` | `copy2`/`move` silently overwrite same-basename files under `--recursive`; the progress line counts sources, not survivors. | Medium |
| `datasets/ome_import/controller.py:55` | `_launch` returns silently on an empty source or destination with no `jobFinished`, so a queued job is marked `running` and the queue bridge stalls forever. | Medium |
| `datasets/subset/apply.py:120`, `concatenate/apply.py:436`, `merge_plates/apply.py:243` | The `seg_fp` restamp is set only inside `with swallow(...)`; on a failed stat the entry silently keeps the **source** dataset's fingerprint and the carried-over override is later discarded as stale. | Low |

## Theme 6 — Persistence and cross-dataset state leakage

| Location | Problem | Severity |
|---|---|---|
| `well_viewer/persistence/registry.py:53` + `allwell.py:1594` | The 500 ms debounce has no flush-all; `closeEvent` force-saves only `view_state`. An edit to ratios, heatmap layouts, cell overrides, line order, plot groups, notes, sample definitions, QC params or crop region made within 500 ms of ⌘W is lost, and a pending timer surviving `begin_load` writes into the **next** dataset's files. | High |
| `well_viewer/persistence/view_state.py:595` + `load_controller.py:321` | `ExportPrefsState.axis_prefs` (per-figure x/y limits, log flags, mark styling) survives a dataset swap; `apply_export_style_prefs` re-applies plate A's `y_lim_max` to plate B on every redraw. | High |
| `well_viewer/persistence/_doc.py:204` | An unreadable `persistence.json` degrades to `{}` and the next `set_section` writes that back, erasing every other section. | Medium |
| `well_viewer/persistence/cell_overrides.py:62,108,186` | `except OSError: pass` plus an absent `<well>_out.zip` makes the v2 staleness fingerprint fail open, and the compensating warning is gated on `file_version < 2`, so a v2 file warns about nothing. | Medium |
| `well_viewer/persistence/reset_scopes.py:270` | `VIEW_DOMAINS` claims `line_order` but `reset_view` never saves it, so the stale order returns on the next load and permanently reorders `selections`. The module's own promise is "what resets live must equal what is dropped from disk". | Medium |
| `well_viewer/persistence/view_state.py:105,462` | `absent_wells` / `absent_solo` survive a dataset swap and are reassigned only inside `restore()`, which is skipped when the new dataset has no `view_state` section: dataset A's wells get unioned into B's saved selection. | Medium |
| `well_viewer/persistence/heatmap_layouts.py:130,264` | The heatmap timepoint is persisted as a combo **index**, which §9.7's add-timepoints workflow invalidates. | Medium |
| `well_viewer/persistence/sample_definitions.py:216` | `well_labels` are hydrated pruned to loaded wells and then autosaved back, erasing labels for wells absent from a subset load. `view_state` solved this with `absent_wells`; this path did not. | Medium |
| `well_viewer/persistence/smfish.py:123`, `well_viewer/domain/gating_state.py:200` | Unlocked read-modify-write of `pipeline_info.json` from a viewer sharing a window with a running Analyze pass; a lost update reverts `available_timepoints` / `fluor_tokens` — the §12.3 symptom. | Medium |
| `well_viewer/core/channel_state_controller.py:150` | A bare mid-function `return` skips `apply_range` and the whole gating-hydration tail, so `threshold_min/max` keep the previous dataset's range (`begin_load` clears only the cache). | Medium |
| `well_viewer/features/smfish/tab_view.py:919` → `persistence/smfish.py:111` | An aborted run's `_after_csv` stamps the old threshold into the **new** dataset's `pipeline_info.json`. | High |
| `well_viewer/features/home/groups/panel_view.py:78` | A plate edit rewrites a group's membership from the plate alone, permanently dropping wells the current dataset does not hold — and autosaves that. | Low |
| `well_viewer/persistence/_doc.py:214` | A `schema_version` mismatch logs "applying defaults" and then uses the doc unchanged: no migration, no discard (contrast `view_state._migrate`). | Low |
| `well_viewer/features/saved_plots/tab_view.py:124` | `_confirm_clear` falls through to clearing when the confirmation dialog raises — an unconfirmed destructive wipe of the gallery and its PNGs. | Medium |

## Theme 7 — Export does not match the screen

| Location | Problem | Severity |
|---|---|---|
| `well_viewer/features/batch_export/scatter_panel.py:481,695,735` | Batch scatter-cells collects with `gates=None`, so the export never applies the Apply-gates point filter the tab applies at `scatter/controller.py:128`. The exported figure contains points the on-screen plot excludes. | Critical |
| `well_viewer/features/export/service.py:638` | The on-tab Scatter "Export CSV" has the same omission: the CSV holds cells the plot excluded. | Critical |
| `well_viewer/features/image_browser/image_table/export.py:371,422` | The export figure builder has no ratio-channel branch (the live grid has one), so every ratio cell exports as `(no image)` in Export to File, Copy PNG, Copy SVG and Save to Saved Plots. | High |
| `well_viewer/features/export/service.py:735,762` | `export_scatter_agg_data` keys rows and fieldnames by the statistic string, so `stat_x == stat_y` silently replaces the X column with Y (reproduced). | High |
| `well_viewer/features/export/service.py:655,678` | The same defect in `export_scatter_data`, keyed by `col_x`/`col_y`. | Medium |
| `well_viewer/features/multivariate/renderer.py:52` | `render_multivariate` never calls `apply_export_style_to_current`, so Properties-sidebar edits die on the next recompute — a direct §5.8 violation. | High |
| `well_viewer/features/export/sidebar_view.py:1063` | `_redraw_active_plot` has a Spatial branch but no Multivariate one, so Reset-defaults never repaints `_mv_fig`. | Medium |
| `well_viewer/core/plot_card_actions.py:189` | `_active_card` takes the roster-first visible card while `copy_active_card_as_svg` / `save_active_card_figure` are wired to 16 per-tab Export menus. In Split View, Bar Plots' own "Copy SVG" copies the line figure. The file's own docstring describes this hazard and fixes only one of the three actions. | Medium |
| `well_viewer/features/batch_export/scatter_panel.py:793` | The multi-timepoint aggregate `_draw` omits `color=data["color"]` that the single-tp sibling and the tab both pass. | Medium |
| `well_viewer/features/batch_export/base_panel.py:1747`, `bar_panel.py:274` | val_col and metric are re-read per job while the channel token is snapshotted, across a `processEvents()` pump. | Medium |
| `well_viewer/features/saved_plots/controller.py:282` vs `tab_view.py:149` | The PDF report writes pages in storage order — the reverse of the gallery order the ▲/▼ buttons curate. | Medium |
| `well_viewer/features/image_browser/image_table/controller.py:835` | The pre-rendered-RGB branch skips chrome and the raw badge and uses a different contrast than the export path for the same cell. | Low |
| `well_viewer/features/multivariate/renderer.py:196` | SPLOM hardcodes `color_by="group"`, ignoring the control. | Low |
| `well_viewer/features/batch_export/base_panel.py:664` | Conditional scope restore leaves the app in the batch's scope on one branch. | Low |

## Theme 8 — Controls that cannot work

The repo's §7.6 lesson — "a control that exists is not a control that works" — is
still live in several places.

| Location | Problem | Severity |
|---|---|---|
| `widgets/plate_progress.py:224` | `setAttribute(WA_TransparentForMouseEvents, True)` on the status plate makes its whole subtree invisible to hit-testing, so the `event(ToolTip)` handler wired eight lines later can never run. Verified on a real `RunDashboard`: `root.childAt(<centre of A01>)` returns the plain centre-column widget. The per-well counts ARCHITECTURE §7 says "live in the well's hover tooltip" (`FOV 7/12`, `downloading 42%`) exist nowhere else, on any dashboard. | High |
| `well_viewer/features/home/ratios/tab_view.py:204` | "− Remove selected" can never remove a ratio: every cell is a cell widget and the vertical header is hidden, so `currentRow()` is always `-1` and `selectedIndexes()` is always empty. Verified by running the real panel. | High |
| `well_viewer/features/home/collect.py:576,589` | Home's "Ratios" count reads `pipeline_info.json["ratios"]`, a key nothing writes (ratios live in `persistence.json`), so the row always reads "None yet". | Medium–High |
| `well_viewer/features/home/pipeline_info/tab_view.py:136` | The QC rows read `qc_remove_debris` / `qc_min_area` / `qc_max_area` / `qc_min_solidity`; the sidecar writes the un-prefixed names, so the run receipt shows "—" and the literal "None, None". | Medium |
| `well_viewer/features/home/collect.py:571,581` | "Wells labelled" uses `len(well_labels)` as the denominator, and that map holds only non-empty labels, so the row can only ever say "N of N". | Medium |
| `well_viewer/features/home/cell_gating/controller.py:608` | The Included/funnel readout is never refreshed on a dataset load, so it keeps describing the previous dataset. | Medium |
| `well_viewer/features/spatial/controller.py:473` | `ctx.state.dataset.dir` does not exist, so Save-As always opens in the process CWD. | Low |
| `well_viewer/core/tab_controller.py:43` | The core tab dispatcher's readiness probe is `_line_ax_mean`, registered only by `features/lineplot/tab_view.py`. Drop Line Graphs — a supported build profile — and `on_tab_change` returns forever. | Medium |
| `well_viewer/core/load_controller.py:170` | Core reads the feature-owned `state.heatmap` slice unconditionally, two lines from the same function's correct `feature_slice()` guards. Removing Heat Map breaks **every** dataset open, and this case is not in `test_feature_removal.py`'s matrix. | Medium |
| `well_viewer/core/plot_toggles.py:520` | `toggle_fov_replicates` calls the lazy bar-feature proxy unconditionally while the sibling `_redraw_bars` two lines below is visibility-gated: with `features/barplot` deleted the app-global FOV button raises `ModuleNotFoundError` **after** already flipping the state. | Medium |
| `well_viewer/features/home/cell_gating/renderer.py:122` | The ON cutoff (ThreshFracOn) is never drawn on the CDFs, and changing it does not redraw them — unlike its FluorGating sibling. | Low |
| `well_viewer/features/saved_plots/controller.py:254,277`, `well_viewer/features/spatial/controller.py:475` | Modal dialogs opened with `parent=None`, against the repo's documented macOS rule. | Low |

## Theme 9 — Threading and lifecycle

| Location | Problem | Severity |
|---|---|---|
| `well_viewer/features/smfish/worker.py:337` | The write loop can `break` on abort, but `after_csv_cb()` and `done_cb("Apply to All complete…")` fire regardless and `written` is discarded. | High |
| `well_viewer/features/home/cell_gating/controller.py:93,810` | Neither `GatingWorker` nor `_AutoThresholdWorker` is cancelled or waited at shutdown (`teardown_review_pane` covers only smFISH and cell browser); the auto-threshold worker has no cancel flag at all and a restart can leave two live. | High |
| `well_viewer/features/smfish/worker.py:288` | All wells are submitted up front with `shutdown(wait=True)` and no `cancel_futures`, and the thread is never joined: cancel decodes everything anyway and can hang shutdown. | Medium |
| `well_viewer/domain/spatial_compute.py:188` | `_dbscan` rebuilds `seen` per core point — quadratic, on the UI thread (`features/spatial/controller.py:361` calls it inline, there is no worker). Timed: 4 000 cells 0.26 s, 8 000 cells 1.99 s, 16 000 cells 10.69 s. A confluent well freezes Review for tens of seconds per redraw. | Medium |
| `well_viewer/core/load_controller.py:262`, `ui_helpers.py:1249` | `processEvents()` is pumped per-CSV inside `load_directory`, after `begin_load` has emptied the caches, so queued sidebar/commit/log callbacks run against a half-loaded dataset. | Medium |
| `well_viewer/core/channel_state_controller.py:189 ↔ 324` | `set_active_channel ↔ recalculate_threshold` mutual recursion; bounded at depth 2, but it duplicates the gating hydration and emits `channel_changed` (a direct connection) mid-recompute. | Medium |
| `well_viewer/core/plot_toggles.py:49,74` | Append-only SEM/FOV button banks are iterated with no `RuntimeError` guard, while the observer loops directly beneath them guard the identical case. | Medium |
| `widgets/plot_card.py:343,393,437` | Each capture path flips `setPlotTheme` twice, and `plotThemeChanged` is directly connected to full tab recomputes: one hover copy/save click runs two complete recomputes, the first *between* the theme flip and the savefig it wraps. | Medium–Low |
| `widgets/plot_card.py:682` | `_open_stats_popover` builds a fresh `Popover(self)` per click; the overwritten one keeps the card as QObject parent — one leaked hidden top-level popover plus two `SegmentedControl`s per click. | Low |
| `well_viewer/data/zipfile_cache.py:71,103,145` | Eviction, stale-mtime close and `invalidate()` all close a `ZipFile` without taking the per-handle lock that `with_handle` holds. | Medium |

## Theme 10 — Half-swept predicates and duplicated logic

The §7.5 failure mode: several answers to one question, disagreeing in at least one
direction.

| Location | Problem | Severity |
|---|---|---|
| `util/schema_infer.py:208` + `:75` | FOV tokens `f1`–`f12` are valid well labels (`canonical_well_label("f01") == "F01"`), so `_is_well` says yes for every FOV token; both columns score 1.0 and `if f >= best_f` keeps the **last** tie — the FOV slot. Executed against three built folders: `zips → ['experiment','channel','ignore','well','timepoint'] confident=True`. Every image is attributed to well `F01`–`F0n`. Only bites when FOVs number ≤ 12, so it fails on small plates and works on big ones. | Critical |
| `util/schema_infer.py:213` | `_pick_channel_slot` picks the **fewest-distinct** slot while its docstring says "leftmost", so with fewer wells than channels the *well* column is labelled `channel`. Executed: `loose → channels=['A01','A02']`, and `A01` then takes the segmentation role. | Critical |
| `util/channel_roles.py:44,67` | Nuclear is tested before phase and `_pick_nuclear` consults `nir|rfp` before the phase filter, so a name matching both takes the segmentation role and `phase_token` stays empty — which leaves `phase_role_conflicts`, the guard that exists to refuse a run "measured on the wrong image", with nothing to compare. Measured: `['NIR_BF','GFP']` → `NIR_BF: nuclear`, `phase_token=''`. | High |
| `util/channel_roles.py:40` | `_PHASE_HINT_RE` alternates on the bare substring `trans`, so `GFP_transfected` classifies as phase and skips flat-field and background correction for that channel alone. | Medium |
| `well_viewer/features/home/cell_gating/gating_compute.py:221`, `well_viewer/data/data_loading.py:564` | A FluorGating of `0.0`, documented as "off", is still applied as `isfinite(v) & (v > 0)` across every gated channel, so cells with a zero or negative background-subtracted MFI, or a NaN in any unrelated channel, are silently excluded. Measured: 1 of 4 cells survives with all gates at default. | High |
| `well_viewer/domain/tp_match.py:1` vs six live sites | The absolute `1e-6` timepoint match is still live in `barplot/collect.py:593,895`, `heatmap/controller.py:293,302,342`, `barplot/renderer.py:509`. `abs(2/3 - 0.6667) = 3.33e-5`: `tp_close` True, `< 1e-6` False. On a fractional-timepoint plate the same tab draws grouped bars and blanks per-well ones. | Medium |
| `util/fov.py:44,65` | `str(value or "")` — the falsy-zero bug `util/timepoint.py:53` exists to prevent. FOV 0 is indistinguishable from a missing FOV and sorts last: `sorted([1,2,10,0], key=fov_sort_key) → [1,2,10,0]`. `position_to_well_fov` returns 0-based FOV indices, so FOV 0 is not hypothetical. | Medium |
| `datasets/concatenate/apply.py:192` vs `:222`; `merge_plates/apply.py:123` vs `:151` | The copy-as-is branch writes under the **source** filename; every other branch writes canonical `f"{well}.zip"`; the CSV uses a third rule. An unpadded dataset yields `in/A1.zip` beside `out/A01_out.zip`. | Medium |
| `well_viewer/features/lineplot/controller.py:692` | `selected` is not filtered by `well_paths` (the three sibling renderers do), so a stale token reaches `get_rows` → `KeyError`, aborting the redraw before `apply_export_style_to_current`. | High |
| `well_viewer/features/lineplot/controller.py:355` vs `barplot/controller.py:63` | Line falls back to stale `selected_wells` when all groups are hidden; Bar deliberately does not. | Medium |
| `well_viewer/features/barplot/renderer.py:184` vs `:341` | Violin requires `timepoint_hours`; beeswarm falls back to the text column, so one mode is empty where the other is not. | Medium |
| `well_viewer/features/scatter/collect.py:448` | Ten marker shapes cycled while colour encodes timepoint: more than ten groups merge visually and the legend shows two identical swatches. | Medium |
| `well_viewer/features/scatter/callbacks.py:60,100` | Nearest-point search runs in raw data space on a `log10(v+1)`-displayed axis with incommensurate units, and the hover threshold is a hardcoded `0.5` data units. | Medium |
| `well_viewer/data/auto_threshold.py:396` | `build_gating_block` is called without `seg_channel_token`, so a nuclear ThreshFracOn of exactly 50.0 diffs as default and is dropped. ARCHITECTURE §5.7 names this as one of three sites that must know. No live caller today. | Medium |
| `util/schema_infer.py:88` | `_is_fov` accepts only `f\d+`, so a bare-number FOV slot stays `ignore` and FOVs merge. | Low |
| `WellPlateZipper.py:53` vs `util/plate_grid.py:30` | A third spelling of the 96-well vocabulary. | Low |
| `WellPlateZipper.py:208` + `util/schema.py:54` | The shared `validate_schema` demands `channel`; the zipper reads only `well` and its own `--filename_schema` help says so, so `well:fov` is rejected with an error about a field the tool never uses. | Medium |
| `util/image_exts.py:44` | Docstring says `._x.tif` has no image suffix; `is_group_image` returns `True`. | Low |

## Theme 11 — Rendering, theming and widget state

| Location | Problem | Severity |
|---|---|---|
| `widgets/rail_nav.py:303` | The comma group `#RailNavRow:hover QLabel, #RailNavRow[active="true"] QLabel {color: text_primary}` bakes `text_primary` into **every** row label's palette, killing the base `text_secondary` rule. Isolated repro: the `[active]` rule alone gives `[(False,'#98a2b3'),(True,'#e6e9ef')]`; adding the `:hover` sibling to the same group gives `[(True…),(True…)]`. Review's left rail draws every section at full strength and the selected one is not distinguished. | Medium |
| `widgets/segmented_control.py:105` | `_Segment.paintEvent` blanks `opt.text` and draws from the palette; `QStyleSheetStyle` fills only the enabled/disabled colour *groups*, never `:checked`/`:hover`, so those QSS rules are dead. Measured: brightest checked pixel `#969ca9` vs unchecked `#98a2b3`, where `text_primary` is `#E6E9EF`. Only the fill differs. | Medium |
| `widgets/search_input.py:68,77` | `_reposition_hint` gates on `isVisible()`, which is False while any ancestor is hidden — exactly during build and while a popover is closed. Measured on the real `LutSelector`: the "32 / 32" chip opens at `QRect(0,0,56,15)` with right margin 0, corrects to `QRect(202,7,49,15)` only after typing, and regresses on every re-open. `isVisibleTo(self)` is the predicate needed. | Medium |
| `widgets/rail_nav.py:157` | The glyph is rendered at a hardcoded `15` logical px inside a font-derived box (`max(12, fontMetrics().height())`). It is 15×15 in a 14×14 box today, and at 150 % font the box grows and the ink does not — the sweep converted the reservation, not the ink. | Medium |
| `widgets/well_plate_selector.py:310` | `set_well_enabled(w, False)` drops the well from `_selected` but emits no `selectionChanged`, while its sibling `set_enabled_wells` explicitly does. The plate silently desynchronises from the app-wide `_selected_wells`. | Medium |
| `theme.py:1275` | The `_GREY` theme overrides `accent`, `accent_hover`, `accent_pressed`, `accent_dim` and `accent_fg` but **not** `accent2`. ARCHITECTURE §7/§8 require `accent2` to read as a neighbour of `accent`; under `grey` the hue gap goes 38° → 55° with diverging saturation, so the pair stops reading as one family on every remote-run plate. | Medium |
| `theme.py:97` | `text_disabled = "#A0AEC0"` is *brighter* than `text_secondary` `#98A2B3` while claiming the disabled-label role; all seven `:disabled` rules in `qss()` use `text_faint` instead. | Low |
| `widgets/stepper.py:333` | `#Stepper QLineEdit#StepperEdit {color: text_primary}` has no `:disabled` variant and its two-ID specificity beats the app sheet's `QLineEdit:disabled`. Latent — none of the 14 construction sites disables one. | Low |
| `widgets/plot_card.py:543` vs `:651` | `setThemeToggleVisible(False)` hides `_preview_chip`, but `_sync_theme_ui` re-shows it on the next `setPlotTheme`. Latent — no caller uses the API. | Low |
| `widgets/toast.py:70`, `widgets/color_swatch_row.py:254` | Raw `QColor(0,0,0,α)` where `drawer.py:58` uses `with_alpha(theme.Colors.ink_dark, 0.35)` and `popover.py:79` uses the token — four spellings of one shadow across four sibling overlays, two of which cannot follow a theme. | Low |
| `widgets/selection_chip.py:129`, `widgets/plate_progress.py:156`, `widgets/run_dashboard.py:400` | `font-size: 10px` in QSS and bare margin/spacing literals in the two modules whose header comments cite §8 for their *named* width constants. Invisible to `test_hardcoded_tokens.py`, which scans only `setFixed*`/`setMinimum*`/`setMaximum*` arguments. | Low |
| `well_viewer/features/barplot/renderer.py:225` | Violin's `spec.missing` skips the violin but the raw fraction dot was already appended and still draws. | Low |
| `well_viewer/features/barplot/controller.py:319` | `MaxNLocator(integer=False)` contradicts the comment directly above it. | Low |
| `well_viewer/features/scatter/gating.py:242` | Colour-by-time hardcodes `markersize=6`, ignoring the `marker_size` preference. | Low |
| `well_viewer/features/scatter/callbacks.py:118` | A hover miss clears the status line on every mouse move, erasing fold-change shortfall warnings. | Low |

## Theme 12 — Docs, contracts and guard gaps

| Location | Problem | Severity |
|---|---|---|
| `allwell.py:101,792` ← `_Docs/Markdowns/README_WellViewer.md:987` | A bare `<date>` in the manual is parsed by `QTextDocument.setMarkdown` as an unclosed HTML tag, and everything after it is dropped from the render. Repro: `'Para one.\n\nreads *checked <date>* …\n\nAfter paragraph two.\n'` → `'Para one.\nreads checked \n'`. On the real manual every block after line 991 renders empty, so `_render_manual_html` injects 27 anchors for 85 headings and **29 of the 41 `help_topics` targets have none** — help opened from Bar Plots, Cell Gating, Job Queue, Merge Plates and 25 other pages leaves the drawer at the top of a manual that also stops at "Home". `tests/test_help_topics.py` matches topics against markdown headings, never against the render, so it cannot see this. A second bare `<date>` sits at line 3097. | High |
| `well_viewer/domain/stats_compute.py:29` | `domain/` transitively imports PySide6 via `core.channel_state_controller → core.ui_helpers → PySide6.QtCore`. `tests/test_qt_free_layers.py` walks direct imports inside the listed roots only, so a one-hop detour through `core/` is invisible to it while docstrings cite that test as the guarantee. Observed as `ImportError: libQt6Core.so.6` on a bare `import well_viewer.domain.fold_change`. | Medium |
| `pyproject.toml:72` + 45 sites | `F821` is disabled globally, which is the blind spot CLAUDE.md §7.5 #11 records. All 45 current hits are annotation-only under `from __future__ import annotations` (harmless at runtime, fatal to `typing.get_type_hints`), including `pipeline/io.py:454` where `io` is never imported. | Low |
| `boot_diag.py:171,178,195,214,240,245`, `mpl_bootstrap.py:98` | Seven broad `except Exception: pass` handlers. Both files sit outside `test_no_silent_except.py`'s roots, so the rule CLAUDE.md states as "no silent `except Exception: pass` anywhere" is unenforced there. Defensible in pre-logging startup code; the coverage gap is the finding. | Low |
| `well_viewer/core/event_bus.py:44` | `redraw_requested` has no emitter and no subscriber, while ARCHITECTURE §5.9 claims every bus signal is load-bearing and `test_architecture_contracts.py:449` freezes the dead signal in place. | Low |
| `well_viewer/core/app_state.py:33` | `_FEATURE_STATE_OWNERS` omits `heatmap`, `scatter`, `distribution`, `smfish` and `home`, so those five give a bare `AttributeError` instead of the documented "feature disabled" message. | Low |
| `well_viewer/core/debug_flags.py:21,28` | Two flags ship `True`; ARCHITECTURE §10.2 says "off by default", names a flag (`REVIEW_IMAGE_CHSW_DEBUG`) that does not exist, and `allwell.py:1686` wires only 4 of 9. | Low |
| `well_viewer/core/plot_style.py:415` | `figure_pref_key(ctx, None)` matches the first *unregistered* slot (`None is None`), returns a wrong key and skips its own anti-silence warning; `redraw_app:177` can pass `None`. | Low |
| `well_viewer/core/selection_controller.py:917` | `has_plottable_selection`'s docstring claims four callers it does not have; the divergence it papers over is the lineplot `well_paths` filter above. | Medium |
| `_Docs/Markdowns/ARCHITECTURE.md:7642` | §12.4 points at `preview/controller.classify_member`; the implementation is in `well_viewer/data/zip_members.py`, and that module is a re-export shim. | Low |
| `_Docs/Markdowns/ARCHITECTURE.md:1592` vs `:1535` | The Home section states both `role="editor"` and `role="picker"` for the same plate; the code uses `"editor"`. | Low |
| `well_viewer/domain/selections_model.py:244` | Docstring says a 48-colour palette; `len(theme.WELL_COLORS_TUPLE) == 96`. | Low |
| `well_viewer/domain/selections_model.py:610` | `from_block`'s docstring says it returns 4 values; it returns 5, so a caller unpacking the documented shape raises `ValueError`. | Low |
| `CLAUDE.md` | States ARCHITECTURE.md is "~2600 lines"; it is 8,171. | Low |
| `util/retry_io.py:181,167` | The exhausted-budget `OSError(str)` carries `errno=None` and says "write" for read call sites; `cleanup` is skipped for non-`OSError` failures, contradicting "after every failed attempt". | Low |
| `util/zip_write.py`, `datasets/_common/containers.py:340` | Two docstrings state atomicity/readability guarantees the code does not provide (see Theme 5). | Low |
| `mpl_bootstrap.py:38` | `.mplcache` lands inside `sys._MEIPASS` in a frozen build, not the "stable" directory promised. | Low |
| `well_viewer/features/home/collect.py:180` + `controller.py:430` | Wells loaded but absent from the completeness record are disabled and unpainted on Home's plate with no legend row, so they cannot be selected there. | Low |

---

## What the reviewers checked and cleared

Worth recording so it is not re-derived:

- **`swallow` / `swallowed` misuse** (the §7.6 bug class): AST-verified clean across
  every reviewed package. No `with swallowed():`, no `swallowed()` outside an
  `except`. The two helper pairs (`core/safe.py`, `util/aw_safe.py`) were executed
  and behave identically.
- **Cross-thread `QTimer.singleShot`**: none anywhere. The smFISH, cell-browser and
  playground workers all marshal through queued signals with generation tokens and
  never touch widgets.
- **`util/well_token`, `util/plate_grid`, `util/timepoint`**: executed exhaustively
  (all 96 serpentine indices both directions, raster, origins, bounds; the full
  timepoint grammar including zero) — correct.
- **`widgets/` app coupling**: no `well_viewer` import, no hardcoded well ids.
- **The dial/sphere both-halves-through-one-transform hazard**: handled (RGB blend,
  not `QColor.lighter`; relief damped; wedge separately stroked).
- **Datasets marker discipline**: marker written first, sources unlinked only after
  verify + sidecar; `clear_destination` only behind `dest_is_restart`.
  `replace_folder_with_archive` never deletes an unarchived file.
- **Statistics that are right**: ΔΔCt stacking order, quadrature propagation both
  directions, Ripley's K normalisation, `variance_decomposition`, `pca_svd` EVR
  denominator, clustering runs on the matrix that is plotted.
- **Quick Replicates** orderings, the label-grid token mapping, `PANE_MODES` ↔
  mode-bar ↔ stack agreement, and `boot_diag` crash-log rotation.

## Method and caveats

- Static reading plus targeted execution of pure functions; the GUI was never driven
  end to end, and the test suite was not run.
- Findings marked *latent* have no live caller today and are reported because the
  code is wrong, not because a user can reach it.
- Every "Confirmed" item was either executed or read to an unambiguous code path.
  A handful of items are marked Plausible in the per-area reports where the
  mechanism is confirmed but no live producer was found; those are noted inline.
